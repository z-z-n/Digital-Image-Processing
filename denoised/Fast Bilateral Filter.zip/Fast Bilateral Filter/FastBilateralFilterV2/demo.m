% Fast Bilateral Filtering using Trigonometric Kernels
%
%  fin           : input grayscale image
%  fout         : bilateral filter output
%  sigmas     : width of spatial Gaussian
%  sigmar     : width of range Gaussian
%
%  Authors   : Kunal N. Chaudhury, Sanjay Ghosh, Anmol Popli.
%  Date        : July 1, 2016.
%
%  References:
%
%  [1] K.N. Chaudhury, D. Sage, and M. Unser, "Fast O(1)
% bilateral filtering using trigonometric range kernels," IEEE
% Transactions on Image Processing, vol. 20, no. 11, 2011.
%
% [2] K.N. Chaudhury, "Acceleration of the shiftable O(1)
% algorithm for bilateral filtering and non-local means,"
% IEEE Transactions on Image Processing, vol. 22, no. 4, 2013.
%
% [3] S. Ghosh and K.N. Chaudhury, "On fast bilateral filtering
% using Fourier kernels,"  IEEE Signal Processing Letters,
% vol. 23, no. 5, pp. 570-573, 2016.
%
clc, clear, close all force;
fin  =  double( imread('./images/cameraman256.png') );
[m, n] = size(fin);
% filter parameters
sigmas = 5;
sigmar = 40;
% call bilateral filter
[fout, param] = shiftableBF(fin, sigmas, sigmar);
% plots
T = param.T;
t = - T : 0.01 : T;
gexact = exp(-0.5*t.^2/sigmar^2);
g = zeros(1,length(t));
T0 = max(T,ceil(3*sigmar));
w0 = pi/T0;
for n = 1:length(param.coeff)
    g = g + param.coeff(n)*cos((n-1)*w0*t);
end
figure,
h1=plot(t,gexact, 'r'); hold on, h2=plot(t,g,'k');
hleg=legend('Target Gaussian','Fourier Approximation');
set(hleg,'fontsize',12);
axis tight; grid on;
% results
figure('Units','normalized','Position',[0 0.5 1 0.5]);
colormap gray,
subplot(1,2,1), imshow(uint8(fin)),
title('Input', 'FontSize', 20), axis('image', 'off');
subplot(1,2,2), imshow(uint8(fout)),
title('Output','FontSize', 20), axis('image', 'off');